<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:11;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"octOf4ks7EJGsEi6FtxiBD3Lfxdc";s:7:"user_id";i:21;s:8:"nickname";s:11:"Uснizzzzz";s:9:"avatarurl";s:126:"https://wx.qlogo.cn/mmopen/vi_32/S6h3pRIScQucKiadErhKa7xIGwiaTEc7LJFaCqE0pq1S7jdDvx96FlK80JDYpZ8y2VNSZicEAERq8xNbPTwHLh5zQ/132";s:9:"logintype";s:6:"weixin";s:10:"expires_in";i:1000000;s:5:"token";s:40:"856cf0d12f7044f6d94a218f070cc1a9c3860275";}