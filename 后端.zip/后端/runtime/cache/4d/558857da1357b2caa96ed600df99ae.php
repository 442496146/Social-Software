<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:20;s:8:"username";s:11:"15861819973";s:7:"userpic";s:86:"https://tangzhe123-com.oss-cn-shenzhen.aliyuncs.com/Appstatic/qsbk/demo/datapic/19.jpg";s:8:"password";s:60:"$2y$10$0EgxGKyhNYYrzqgac.PR5e0A/8EuGq1zuXhV3KDdcoLhKEl0KuRy6";s:5:"phone";s:11:"15861819973";s:5:"email";s:16:"123456788@qq.com";s:6:"status";i:1;s:11:"create_time";s:19:"2020-06-11 21:23:28";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"b7674db80a269bcb11c71137c508ef3f1357e459";}