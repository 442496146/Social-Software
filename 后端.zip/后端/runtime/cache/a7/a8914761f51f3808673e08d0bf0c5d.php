<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:13;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"octOf4kgr54Q_CcCbhybL835tvmI";s:7:"user_id";i:20;s:8:"nickname";s:7:"南皑.";s:9:"avatarurl";s:128:"https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKDgvKIdeUrtumDsh5nTy0pIaJF5wicEL07m6WaBOyuuQzhAiaicaQrIoudxTanK2q51XniaYDKoic6bYQ/132";s:9:"logintype";s:6:"weixin";s:10:"expires_in";i:1000000;s:5:"token";s:40:"cfb0b347805c05e99988f3914086e227d2c8245f";}