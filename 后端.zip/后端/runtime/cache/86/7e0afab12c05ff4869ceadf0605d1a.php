<?php
//000001000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:8;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"octOf4oEgIbb0-NeQ6wucnABMlZM";s:7:"user_id";i:1;s:8:"nickname";s:9:"Peng Wong";s:9:"avatarurl";s:125:"https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83ertT1lhnHiaoUNLM4Qcb5mFgxRMBtnJmPHBKRltC0yFEeABpkNlMBN6aRKIXGRmibMPzAm9R5C5mutw/132";s:9:"logintype";s:6:"weixin";s:10:"expires_in";i:1000000;s:5:"token";s:40:"4c50ea6567c6dbbd0f0bae13a2f008fe9a53bcf7";}