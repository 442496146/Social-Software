<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:1;s:8:"username";s:5:"Jason";s:7:"userpic";s:85:"https://tangzhe123-com.oss-cn-shenzhen.aliyuncs.com/Appstatic/qsbk/demo/datapic/9.jpg";s:8:"password";s:60:"$2y$10$0EgxGKyhNYYrzqgac.PR5e0A/8EuGq1zuXhV3KDdcoLhKEl0KuRy6";s:5:"phone";s:11:"17718140224";s:5:"email";s:16:"123456789@qq.com";s:6:"status";i:1;s:11:"create_time";s:19:"2020-05-26 22:02:22";s:9:"logintype";s:8:"username";s:5:"token";s:40:"b4483479552f8e3d06c937f09eefe0fe8a0608e1";}