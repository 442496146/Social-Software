<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"17718140225";s:5:"phone";s:11:"17718140225";s:11:"create_time";s:19:"2020-06-01 22:29:13";s:11:"update_time";s:19:"2020-06-01 22:29:13";s:2:"id";s:2:"17";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"c4960179d726f17a03b0c9cb3286ff4a2d6d5194";}