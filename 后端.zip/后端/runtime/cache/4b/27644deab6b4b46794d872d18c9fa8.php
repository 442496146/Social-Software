<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"17718140224";s:5:"phone";s:11:"17718140224";s:8:"password";s:60:"$2y$10$wjwqFyjNou6nhNeQw8HFz...r1BHj3Q7N3sprDZVco8GgNHyKp8d.";s:11:"create_time";s:19:"2020-05-26 22:02:22";s:11:"update_time";s:19:"2020-05-26 22:02:22";s:2:"id";s:2:"15";s:5:"token";s:40:"e503a0b32bc2865417f6923038123591448684e4";}