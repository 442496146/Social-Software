<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:1;s:8:"username";s:5:"Jason";s:7:"userpic";s:85:"https://tangzhe123-com.oss-cn-shenzhen.aliyuncs.com/Appstatic/qsbk/demo/datapic/9.jpg";s:8:"password";s:60:"$2y$10$byRlE/MuJ32Ojt4okh47..puFuXk3KIOyMJ9kRyCECVEHPBBbtUya";s:5:"phone";s:11:"17718140224";s:5:"email";s:17:"1055406839@qq.com";s:6:"status";i:1;s:11:"create_time";s:19:"2020-05-26 22:02:22";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"34820b18f443df58dd301a6c214b97e28c38c366";}