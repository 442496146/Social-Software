<?php
//000000000000
 exit();?>
think_serialize:a:2:{i:0;a:7:{s:5:"to_id";s:2:"22";s:7:"from_id";i:1;s:13:"from_username";s:5:"Jason";s:12:"from_userpic";s:85:"https://tangzhe123-com.oss-cn-shenzhen.aliyuncs.com/Appstatic/qsbk/demo/datapic/9.jpg";s:4:"type";s:4:"text";s:4:"data";s:6:"杨欢";s:4:"time";i:1591977062;}i:1;a:7:{s:5:"to_id";s:2:"22";s:7:"from_id";i:1;s:13:"from_username";s:5:"Jason";s:12:"from_userpic";s:85:"https://tangzhe123-com.oss-cn-shenzhen.aliyuncs.com/Appstatic/qsbk/demo/datapic/9.jpg";s:4:"type";s:4:"text";s:4:"data";s:15:"有消息吗？";s:4:"time";i:1591977582;}}