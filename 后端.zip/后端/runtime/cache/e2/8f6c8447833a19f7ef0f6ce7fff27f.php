<?php
//000000007200
 exit();?>
think_serialize:a:7:{s:4:"type";s:6:"weixin";s:6:"openid";s:28:"oRrdQt3HS3Ns2TFCVLMOyxbR9DcA";s:8:"nickname";s:6:"测试";s:9:"avatarurl";s:131:"http://thirdwx.qlogo.cn/mmopen/vi_32/WiaWkkJjnG4WhI2KERDGPanF9GlNM3SWDTibibKEuHru1Jrd4pfGwialjn5tTCVLvEOq8RnZ8QmqkxyNAYXtuuGcBg/132";s:2:"id";s:1:"4";s:10:"expires_in";s:4:"7200";s:5:"token";s:40:"2e58fca286cd8dd3a2b07d14ca58278925640ab8";}