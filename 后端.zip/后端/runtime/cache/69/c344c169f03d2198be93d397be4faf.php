<?php
//000000000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:15;s:8:"username";s:11:"17718140224";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$wjwqFyjNou6nhNeQw8HFz...r1BHj3Q7N3sprDZVco8GgNHyKp8d.";s:5:"phone";s:11:"17718140224";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";s:19:"2020-05-26 22:02:22";s:5:"token";s:40:"23cf2d140530ae7eabef8c1badea4b7d7dce174d";}