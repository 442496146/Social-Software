<?php
//000000007200
 exit();?>
think_serialize:a:9:{s:2:"id";i:4;s:4:"type";s:6:"weixin";s:6:"openid";s:28:"oRrdQt3HS3Ns2TFCVLMOyxbR9DcA";s:7:"user_id";i:1;s:8:"nickname";s:6:"测试";s:9:"avatarurl";s:131:"http://thirdwx.qlogo.cn/mmopen/vi_32/WiaWkkJjnG4WhI2KERDGPanF9GlNM3SWDTibibKEuHru1Jrd4pfGwialjn5tTCVLvEOq8RnZ8QmqkxyNAYXtuuGcBg/132";s:9:"logintype";s:6:"weixin";s:10:"expires_in";s:4:"7200";s:5:"token";s:40:"dc5c23ac4c31aca1812672411c83edc63c8d11f3";}