<?php
//000000000000
 exit();?>
think_serialize:a:6:{s:8:"username";s:11:"17718140224";s:5:"phone";s:11:"17718140224";s:11:"create_time";s:19:"2020-05-26 21:57:02";s:11:"update_time";s:19:"2020-05-26 21:57:02";s:2:"id";s:2:"14";s:5:"token";s:40:"8b49e6d5a036bdbc4f33005fbd80e19a7d213a9d";}