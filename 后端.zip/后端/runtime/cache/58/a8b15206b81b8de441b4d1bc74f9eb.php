<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:1;s:8:"username";s:11:"17718140224";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$wjwqFyjNou6nhNeQw8HFz...r1BHj3Q7N3sprDZVco8GgNHyKp8d.";s:5:"phone";s:11:"17718140224";s:5:"email";s:17:"1055406839@qq.com";s:6:"status";i:1;s:11:"create_time";s:19:"2020-05-26 22:02:22";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"db81bd471cfa1344c9002451542051ad80735af3";}