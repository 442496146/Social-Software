// 配置信息
export default {
	// api请求前缀
	webUrl:'https://hci.lovepeach.cn/api/v1',
	// websocket地址
	websocketUrl:"wss://hci.lovepeach.cn/wss",
	// 消息提示tabbar索引
	TabbarIndex:2
}